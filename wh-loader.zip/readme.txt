=== WH Loader ===
Contributors: Jubayer
Tags: loader, preloader, spinner, animation, branding
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.0
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A sleek Windows 11 style preloader for your website. Fully customizable brand name and colors via the WordPress dashboard.

== Description ==

WH Loader is a professional, high-performance Windows 11 style preloader designed for brand consistency and user experience. It features a sleek 4-pane animated block sequence that circles smoothly while your website loads.

Fully customizable via the WordPress Dashboard, WH Loader allows you to change the background color, brand name, and accent colors to match your identity perfectly.

== Installation ==

1. Upload the `wh-loader` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to **Settings > WH Loader** to customize your brand name and colors.

== Frequently Asked Questions ==

= Does it affect SEO? =
No, the loader is designed to fade out once the DOM is ready and does not prevent search engines from crawling your content.

= Can I change the speed? =
Currently, the speed is optimized for a premium feel (2.4s cycle), but you can request this feature in future updates.

== Screenshots ==

1. The WH Loader in action with default Dark Blue theme.
2. The easy-to-use settings dashboard.

== Changelog ==

= 1.1.2 =
* Updated author name & url, contributors name.

= 1.1 =
* Added Dashboard Settings menu.
* Added customization for Brand Name, Background, and Spinner colors.
* Improved fade-out logic for better UX.

= 1.0 =
* Initial release.